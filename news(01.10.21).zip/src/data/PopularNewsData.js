import image1 from "assets/popularNews/video1.png"
import image2 from "assets/popularNews/video2.png"

export default {
    leftHead: "Video",
    rightHead: "Opinion",
    videos: [
        {
            video: "https://www.youtube-nocookie.com/embed/o_Ay_iDRAbc",
            image: image1
        },
        {
            video: "https://www.youtube-nocookie.com/embed/O_O7R372rGo",
            image: image2
        },
    ],
    Opinions: [
        {
            name: "Jan-Werner Müller",
            detail: "Stop Comparing Bernie to Trump. It’s Ridiculous."
        },
        {
            name: "Nicholas Kristof",
            detail: "What if Trump Gave Alaska to Putin?"
        },
        {
            name: "Gail Collins",
            detail: "Donald Versus George Washington"
        },
        {
            name: "Jim Mangeia",
            detail: "Gay Men Are Dying From a Crisis We’re Not …"
        },
    ]
}