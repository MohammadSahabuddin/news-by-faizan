import axios from "axios";
import * as actionTypes from "./actionType";

const API_KEY = "qSPUWlpzwoesn5zIizBwJEsUrnBaQl9J";

export const popularSuccess = (popularNewsData) => {
    return {
        type: actionTypes.POPULAR_SUCCESS,
        payload: {
            popularNews: popularNewsData
        }
    }
}
export const todaySuccess = (todayNewsData) => {
    return {
        type: actionTypes.TODAY_SUCCESS,
        payload: {
            todayNews: todayNewsData
        }
    }
}


export const popular = () => dispatch => {
    axios.get("https://api.nytimes.com/svc/mostpopular/v2/emailed/7.json?api-key=" + API_KEY)
        .then(res => {
            dispatch(popularSuccess(res.data.results))
        })
    axios.get("https://api.nytimes.com/svc/topstories/v2/home.json?api-key=" + API_KEY)
        .then(res => {
            dispatch(todaySuccess(res.data.results))
            // console.log(res.data.results);
        })
}

// export const today = () => dispatch => {
//     axios.get("https://api.nytimes.com/svc/topstories/v2/home.json?api-key=" + API_KEY)
//         .then(res => {
//             dispatch(todaySuccess(res.data.results))
//             // console.log(res.data.results);
//         })
// }