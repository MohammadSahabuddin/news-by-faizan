import { combineReducers } from "redux";
import NavigationData from "data/NavigationData";
import HeadlineData from "data/HeadlineData";
import PopularNewsData from "data/PopularNewsData";
import TodayData from "data/TodayData";
import * as actionTypes from "./actionType";

const navigationReducer = (navigationState = NavigationData, action) => {
    switch (action.type) {
        default:
            return navigationState;
    }
};
const headlineReducer = (headlineState = HeadlineData, action) => {
    switch (action.type) {
        default:
            return headlineState;
    }
};
const popularReducer = (popularNews = null, action) => {
    switch (action.type) {
        case actionTypes.POPULAR_SUCCESS:
            return {
                popularNews: action.payload.popularNews
            }
        default:
            return popularNews;
    }
};
const todayReducer = (todayNews = null, action) => {
    switch (action.type) {
        case actionTypes.TODAY_SUCCESS:
            return {
                todayNews: action.payload.todayNews
            }
        default:
            return todayNews;
    }
};

export const Reducer = combineReducers({
    navigation: navigationReducer,
    headline: headlineReducer,
    popularNews: popularReducer,
    today: todayReducer,

})