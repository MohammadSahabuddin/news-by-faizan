import headlineImage from "assets/today/3.png"
import rightContentImage1 from "assets/today/Group1.png"
import rightContentImage2 from "assets/today/Group2.png"
import rightContentImage3 from "assets/today/Group3.png"

export default {
    leftHeading: "Today headlines",
    image: headlineImage,
    headline: "Senate Adopts Framework After Acrimonious Debate",
    details: "Republicans made last-minute changes to their proposed rules to placate moderates, but they held together to turn back Democratic proposals.",
    rightHeading: "Business",
    rightContents: [
        {
            image: rightContentImage1,
            name: "Trade War’s Pain May Deepen Even as Tensions Abate",
            details: "Manufacturers and farmers struggled last year because of tariffs, and there are signs that damage is spreading to other sectors of the economy."
        },
        {
            image: rightContentImage2,
            name: "Trade War’s Pain May Deepen Even as Tensions Abate",
            details: "Manufacturers and farmers struggled last year because of tariffs, and there are signs that damage is spreading to other sectors of the economy."
        },
        {
            image: rightContentImage3,
            name: "Trade War’s Pain May Deepen Even as Tensions Abate",
            details: "Manufacturers and farmers struggled last year because of tariffs, and there are signs that damage is spreading to other sectors of the economy."
        },
    ]
}