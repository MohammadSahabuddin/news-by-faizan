/** @jsxImportSource theme-ui */
import { ThemeProvider } from 'theme-ui';
import { Provider } from 'react-redux';
import theme from 'theme';
import 'typeface-open-sans';
import 'typeface-source-sans-pro';

import myStore from 'redux/store';

function MyApp({ Component, pageProps }) {
  return (
    <Provider store={myStore}>
      <ThemeProvider theme={theme} >
        <Component {...pageProps} />
      </ThemeProvider>
    </Provider>
  )
}

export default MyApp;