import axios from "axios";
import * as actionTypes from "./actionType";

const API_KEY = "qSPUWlpzwoesn5zIizBwJEsUrnBaQl9J";

export const popularSuccess = (popularNewsData) => dispatch => {
    return {
        type: actionTypes.POPULAR_SUCCESS,
        payload: {
            popularNews: popularNewsData
        }
    }
}
export const popular = () => dispatch => {
    axios.get("https://api.nytimes.com/svc/mostpopular/v2/viewed/7.json?api-key=" + API_KEY)
        .then(res => {
            dispatch(popularSuccess(res.data.results))
            // console.log(res)
        })
}