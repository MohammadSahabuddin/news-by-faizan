import { combineReducers } from "redux";
import PopularNewsData from "data/PopularNewsData";
import HeadlineData from "data/HeadlineData";
import TodayData from "data/TodayData";
import NavigationData from "data/NavigationData";
import * as actionTypes from "./actionType";

const popularReducer = (popularState = null, action) => {
    switch (action.type) {
        case actionTypes.POPULAR_SUCCESS:
            return {
                popularState: action.payload.popularNews
            }
        default:
            return popularState;
    }
};
const headlineReducer = (headlineState = HeadlineData, action) => {
    switch (action.type) {
        default:
            return headlineState;
    }
};
const todayReducer = (todayState = TodayData, action) => {
    switch (action.type) {
        default:
            return todayState;
    }
};
const navigationReducer = (navigationState = NavigationData, action) => {
    switch (action.type) {
        default:
            return navigationState;
    }
};

export const Reducer = combineReducers({
    popularNews: popularReducer,
    headline: headlineReducer,
    today: todayReducer,
    navigation: navigationReducer
})